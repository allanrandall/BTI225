// Data for the "HTML Audio" Page

var audio = {
    controls: true, 
    source: [
        {src: "https://github.com/allanrandall/BTI225W17/blob/master/Track03.mp3?raw=true", type: "audio/mpeg"},
        {src: "https://github.com/allanrandall/BTI225W17/blob/master/Track03.ogg?raw=true", type: "audio/ogg"}
    ]
};